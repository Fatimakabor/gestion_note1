package com.example.gestions_des_notes.DAO;

import com.example.gestions_des_notes.models.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GradeRepo extends JpaRepository<Grade, Long> {

    // Trouver toutes les notes d'un étudiant
    List<Grade> findByStudentId(Long studentId);

    // Trouver toutes les notes d'un module
    List<Grade> findByModuleId(Long moduleId);

    // Trouver toutes les notes d'un élément
    List<Grade> findByElementId(Long elementId);

    // Trouver toutes les notes d'un étudiant dans un module
    List<Grade> findByStudentIdAndModuleId(Long studentId, Long moduleId);
}