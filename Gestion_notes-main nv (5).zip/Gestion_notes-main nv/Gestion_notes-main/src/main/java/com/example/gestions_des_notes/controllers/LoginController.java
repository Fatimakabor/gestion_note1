package com.example.gestions_des_notes.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

    @GetMapping("/login")
    public String login() {
        return "login"; // Retourne le nom de la vue (login.html ou login.jsp)
    }
}