package com.example.gestions_des_notes.DAO;
import com.example.gestions_des_notes.models.Element;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ElementRepo extends JpaRepository<Element, Long> {
    // Vous pouvez ajouter des méthodes personnalisées ici si nécessaire
}
