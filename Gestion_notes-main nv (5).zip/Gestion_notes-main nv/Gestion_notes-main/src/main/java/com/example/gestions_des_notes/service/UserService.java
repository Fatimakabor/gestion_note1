package com.example.gestions_des_notes.service;


import com.example.gestions_des_notes.DAO.UserRepo;
import com.example.gestions_des_notes.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;

    // Create a new user
    public User createUser(User user) {
        return userRepo.save(user);
    }

    // Get all users
    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

    // Get a user by ID
    public Optional<User> getUserById(Long id) {
        return userRepo.findById(id);
    }

    // Update an existing user by ID
    public User updateUser(Long id, User userDetails) {
        User existingUser = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));

        // Update the fields of the existing user
        existingUser.setUsername(userDetails.getUsername());
        existingUser.setPassword(userDetails.getPassword());
        existingUser.setRole(userDetails.getRole());
        existingUser.setEnabled(userDetails.isEnabled());

        return userRepo.save(existingUser);
    }

    // Delete a user by ID
    public void deleteUser(Long id) {
        userRepo.deleteById(id);
    }

    // Disable a user by ID
    public void disableUser(Long id) {
        User user = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
        user.setEnabled(false);
        userRepo.save(user);
    }

    // Enable a user by ID
    public void enableUser(Long id) {
        User user = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
        user.setEnabled(true);
        userRepo.save(user);
    }
}