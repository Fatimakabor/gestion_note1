package com.example.gestions_des_notes.controllers;

import com.example.gestions_des_notes.models.AuditLog;
import com.example.gestions_des_notes.service.AuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/audit-logs")
public class AuditLogController {

    @Autowired
    private AuditLogService auditLogService;

    @PostMapping
    public AuditLog createAuditLog(@RequestBody AuditLog auditLog) {
        return auditLogService.saveAuditLog(auditLog);
    }

    @GetMapping
    public List<AuditLog> getAllAuditLogs() {
        return auditLogService.getAllAuditLogs();
    }

    @GetMapping("/action/{action}")
    public List<AuditLog> getAuditLogsByAction(@PathVariable String action) {
        return auditLogService.getAuditLogsByAction(action);
    }

    @GetMapping("/entity/{entity}")
    public List<AuditLog> getAuditLogsByEntity(@PathVariable String entity) {
        return auditLogService.getAuditLogsByEntity(entity);
    }

    @GetMapping("/entity-id/{entityId}")
    public List<AuditLog> getAuditLogsByEntityId(@PathVariable Long entityId) {
        return auditLogService.getAuditLogsByEntityId(entityId);
    }

    @GetMapping("/user/{modifiedBy}")
    public List<AuditLog> getAuditLogsByUser(@PathVariable String modifiedBy) {
        return auditLogService.getAuditLogsByUser(modifiedBy);
    }

    @GetMapping("/between-dates")
    public List<AuditLog> getAuditLogsBetweenDates(
            @RequestParam Date startDate,
            @RequestParam Date endDate) {
        return auditLogService.getAuditLogsBetweenDates(startDate, endDate);
    }

    @GetMapping("/entity-action")
    public List<AuditLog> getAuditLogsByEntityAndAction(
            @RequestParam String entity,
            @RequestParam String action) {
        return auditLogService.getAuditLogsByEntityAndAction(entity, action);
    }

    @GetMapping("/entity-action-user")
    public List<AuditLog> getAuditLogsByEntityActionAndUser(
            @RequestParam String entity,
            @RequestParam String action,
            @RequestParam String modifiedBy) {
        return auditLogService.getAuditLogsByEntityActionAndUser(entity, action, modifiedBy);
    }
}