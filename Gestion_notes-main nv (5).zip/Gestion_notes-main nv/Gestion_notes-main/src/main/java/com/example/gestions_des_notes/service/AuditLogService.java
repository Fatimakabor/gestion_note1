package com.example.gestions_des_notes.service;


import com.example.gestions_des_notes.DAO.AuditLogRepo;
import com.example.gestions_des_notes.models.AuditLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class AuditLogService {

    @Autowired
    private AuditLogRepo auditLogRepo;

    // Save a new audit log
    public AuditLog saveAuditLog(AuditLog auditLog) {
        return auditLogRepo.save(auditLog);
    }

    // Get all audit logs
    public List<AuditLog> getAllAuditLogs() {
        return auditLogRepo.findAll();
    }

    // Get audit logs by action
    public List<AuditLog> getAuditLogsByAction(String action) {
        return auditLogRepo.findByAction(action);
    }

    // Get audit logs by entity
    public List<AuditLog> getAuditLogsByEntity(String entity) {
        return auditLogRepo.findByEntity(entity);
    }

    // Get audit logs by entity ID
    public List<AuditLog> getAuditLogsByEntityId(Long entityId) {
        return auditLogRepo.findByEntityId(entityId);
    }

    // Get audit logs by user
    public List<AuditLog> getAuditLogsByUser(String modifiedBy) {
        return auditLogRepo.findByModifiedBy(modifiedBy);
    }

    // Get audit logs between two dates
    public List<AuditLog> getAuditLogsBetweenDates(Date startDate, Date endDate) {
        return auditLogRepo.findByModifiedAtBetween(startDate, endDate);
    }

    // Get audit logs by entity and action
    public List<AuditLog> getAuditLogsByEntityAndAction(String entity, String action) {
        return auditLogRepo.findByEntityAndAction(entity, action);
    }

    // Get audit logs by entity, action, and user
    public List<AuditLog> getAuditLogsByEntityActionAndUser(String entity, String action, String modifiedBy) {
        return auditLogRepo.findByEntityAndActionAndModifiedBy(entity, action, modifiedBy);
    }
}