package com.example.gestions_des_notes.models;


import jakarta.persistence.*;
import java.util.Date;

@Entity
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String entity; // Nom de l'entité (par exemple, "Student", "Grade")
    private Long entityId; // ID de l'entité concernée

    private String action; // Action effectuée (par exemple, "UPDATE", "DELETE")
    private String modifiedBy; // Utilisateur qui a effectué l'action

    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedAt; // Date de l'action

    // Constructeur par défaut (requis par JPA)
    public AuditLog() {
    }

    // Constructeur avec paramètres (facultatif, mais utile)
    public AuditLog(String entity, Long entityId, String action, String modifiedBy, Date modifiedAt) {
        this.entity = entity;
        this.entityId = entityId;
        this.action = action;
        this.modifiedBy = modifiedBy;
        this.modifiedAt = modifiedAt;
    }

    // Getters et Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEntity() {
        return entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }

    public Long getEntityId() {
        return entityId;
    }

    public void setEntityId(Long entityId) {
        this.entityId = entityId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Date getModifiedAt() {
        return modifiedAt;
    }

    public void setModifiedAt(Date modifiedAt) {
        this.modifiedAt = modifiedAt;
    }

    // Méthode toString() pour le débogage (facultatif)
    @Override
    public String toString() {
        return "AuditLog{" +
                "id=" + id +
                ", entity='" + entity + '\'' +
                ", entityId=" + entityId +
                ", action='" + action + '\'' +
                ", modifiedBy='" + modifiedBy + '\'' +
                ", modifiedAt=" + modifiedAt +
                '}';
    }
}