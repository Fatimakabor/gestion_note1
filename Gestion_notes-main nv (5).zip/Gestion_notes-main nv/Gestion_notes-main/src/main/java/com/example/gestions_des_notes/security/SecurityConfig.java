package com.example.gestions_des_notes.security;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(requests -> requests
                        .requestMatchers("/css/**", "/js/**", "/images/**").permitAll() // Autoriser les ressources statiques
                        .requestMatchers("/admin/**").hasRole("ADMIN") // Seul l'admin peut accéder à /admin
                        .requestMatchers("/students/**").hasAnyRole("USER", "ADMIN") // Les utilisateurs et admin peuvent accéder à /students
                        .anyRequest().authenticated() // Toutes les autres requêtes nécessitent une authentification
                )
                .formLogin(form -> form
                        .loginPage("/login") // Page de connexion personnalisée
                        .permitAll() // Autoriser l'accès à la page de connexion pour tous
                )
                .logout(logout -> logout
                        .logoutSuccessUrl("/login?logout") // Redirection après déconnexion
                        .permitAll() // Autoriser la déconnexion pour tous
                )
                .exceptionHandling(exception -> exception
                        .accessDeniedPage("/access-denied") // Page d'erreur personnalisée
                )
                .csrf(csrf -> csrf.disable()); // Désactiver CSRF si nécessaire

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder passwordEncoder) {
        UserDetails admin = User.builder()
                .username("admin")
                .password(passwordEncoder.encode("admin123")) // Encodage sécurisé
                .roles("ADMIN")
                .build();

        UserDetails user = User.builder()
                .username("user")
                .password(passwordEncoder.encode("user123")) // Encodage sécurisé
                .roles("USER")
                .build();

        return new InMemoryUserDetailsManager(admin, user);
    }
}


