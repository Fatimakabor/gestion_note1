package com.example.gestions_des_notes.controllers;

import com.example.gestions_des_notes.models.Student;
import com.example.gestions_des_notes.service.PDFExportService;
import com.example.gestions_des_notes.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/export")
public class PDFExportController {

    @Autowired
    private PDFExportService pdfExportService;

    @Autowired
    private StudentService studentService;

    /**
     * Endpoint pour exporter la liste des étudiants dans un fichier PDF.
     *
     * @return Un fichier PDF contenant les données des étudiants.
     */
    @GetMapping("/students/pdf")
    public ResponseEntity<ByteArrayResource> exportStudentsToPDF() {
        // Récupérer la liste des étudiants
        List<Student> students = studentService.getAllStudents();

        // Générer le fichier PDF
        byte[] pdfBytes = pdfExportService.generateStudentPDF(students);

        if (pdfBytes == null) {
            return ResponseEntity.internalServerError().build(); // Erreur lors de la génération du fichier
        }

        // Préparer la réponse avec le fichier PDF
        ByteArrayResource resource = new ByteArrayResource(pdfBytes);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=students.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(resource);
    }
}