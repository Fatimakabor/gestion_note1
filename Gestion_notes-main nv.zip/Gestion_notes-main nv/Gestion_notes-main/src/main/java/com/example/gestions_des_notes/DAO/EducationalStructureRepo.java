package com.example.gestions_des_notes.DAO;

import com.example.gestions_des_notes.models.EducationalStructure;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EducationalStructureRepo extends JpaRepository<EducationalStructure, Long> {

    // Trouver une structure pédagogique par son nom
    List<EducationalStructure> findByName(String name);

    // Trouver une structure pédagogique par son code
    List<EducationalStructure> findByCode(String code);
}
