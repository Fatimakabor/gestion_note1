package com.example.gestions_des_notes.DAO;

import com.example.gestions_des_notes.models.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface AuditLogRepo extends JpaRepository<AuditLog, Long> {

    // Find all logs by action (e.g., "UPDATE", "DELETE")
    List<AuditLog> findByAction(String action);

    // Find all logs for a specific entity (e.g., "Student", "Grade")
    List<AuditLog> findByEntity(String entity);

    // Find all logs for a specific entity ID
    List<AuditLog> findByEntityId(Long entityId);

    // Find all logs modified by a specific user
    List<AuditLog> findByModifiedBy(String modifiedBy);

    // Find all logs between two dates
    List<AuditLog> findByModifiedAtBetween(Date startDate, Date endDate);

    // Find all logs for a specific entity and action
    List<AuditLog> findByEntityAndAction(String entity, String action);

    // Find all logs for a specific entity, action, and user
    List<AuditLog> findByEntityAndActionAndModifiedBy(String entity, String action, String modifiedBy);
}
