package com.example.gestions_des_notes.controllers;


import com.example.gestions_des_notes.models.Student;
import com.example.gestions_des_notes.service.ExcelExportService;
import com.example.gestions_des_notes.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/export")
public class ExcelExportController {

    @Autowired
    private ExcelExportService excelExportService;

    @Autowired
    private StudentService studentService;

    /**
     * Endpoint pour exporter la liste des étudiants dans un fichier Excel.
     *
     * @return Un fichier Excel contenant les données des étudiants.
     */
    @GetMapping("/students/excel")
    public ResponseEntity<ByteArrayResource> exportStudentsToExcel() {
        // Récupérer la liste des étudiants
        List<Student> students = studentService.getAllStudents();

        // Générer le fichier Excel
        byte[] excelBytes = excelExportService.generateStudentExcel(students);

        if (excelBytes == null) {
            return ResponseEntity.internalServerError().build(); // Erreur lors de la génération du fichier
        }

        // Préparer la réponse avec le fichier Excel
        ByteArrayResource resource = new ByteArrayResource(excelBytes);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=students.xlsx")
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(resource);
    }
}
