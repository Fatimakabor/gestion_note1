package com.example.gestions_des_notes.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ExportViewController {

    /**
     * Affiche la page d'exportation des étudiants.
     *
     * @return Le nom du fichier HTML (sans l'extension) à afficher.
     */
    @GetMapping("/export")
    public String showExportPage() {
        return "export"; // Retourne le nom du fichier HTML (sans l'extension)
    }
}
