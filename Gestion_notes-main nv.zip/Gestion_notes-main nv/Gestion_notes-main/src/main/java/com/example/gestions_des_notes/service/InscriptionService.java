package com.example.gestions_des_notes.service;


import com.example.gestions_des_notes.DAO.InscriptionRepository;
import com.example.gestions_des_notes.models.Inscription;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InscriptionService {

    @Autowired
    private InscriptionRepository inscriptionRepository;

    public Inscription createInscription(Inscription inscription) {
        return inscriptionRepository.save(inscription);
    }

    public List<Inscription> getAllInscriptions() {
        return inscriptionRepository.findAll();
    }

    public Optional<Inscription> getInscriptionById(Long id) {
        return inscriptionRepository.findById(id);
    }

    public List<Inscription> getInscriptionsByStudentId(Long studentId) {
        return inscriptionRepository.findByStudentId(studentId);
    }

    public void deleteInscription(Long id) {
        inscriptionRepository.deleteById(id);
    }
}
