package com.example.gestions_des_notes.models;


import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
public class Inscription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Student student;

    @ManyToOne
    private Level level;

    private LocalDate inscriptionDate;

    private String type; // Example: "NEW_REGISTRATION" or "RE_REGISTRATION"

    // Constructors
    public Inscription() {}

    public Inscription(Student student, Level level, LocalDate inscriptionDate, String type) {
        this.student = student;
        this.level = level;
        this.inscriptionDate = inscriptionDate;
        this.type = type;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public LocalDate getInscriptionDate() {
        return inscriptionDate;
    }

    public void setInscriptionDate(LocalDate inscriptionDate) {
        this.inscriptionDate = inscriptionDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
