package com.example.gestions_des_notes.controllers;

import com.example.gestions_des_notes.models.Inscription;
import com.example.gestions_des_notes.service.InscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*") // Enable CORS for all domains
@RestController
@RequestMapping("/api/inscriptions")
public class InscriptionController {

    @Autowired
    private InscriptionService inscriptionService;

    @PostMapping("/create")
    public ResponseEntity<Inscription> createInscription(@RequestBody Inscription inscription) {
        Inscription saved = inscriptionService.createInscription(inscription);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Inscription>> getAllInscriptions() {
        return ResponseEntity.ok(inscriptionService.getAllInscriptions());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Optional<Inscription>> getInscriptionById(@PathVariable Long id) {
        return ResponseEntity.ok(inscriptionService.getInscriptionById(id));
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<Inscription>> getInscriptionsByStudentId(@PathVariable Long studentId) {
        return ResponseEntity.ok(inscriptionService.getInscriptionsByStudentId(studentId));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteInscription(@PathVariable Long id) {
        inscriptionService.deleteInscription(id);
        return ResponseEntity.noContent().build();
    }
}
