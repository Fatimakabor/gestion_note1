package com.example.gestions_des_notes.models;

import jakarta.persistence.*;

@Entity
public class Module {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private Double passingScore; // Seuil de validation (ex: 12)
    private Double retakeScore;  // Seuil de rattrapage (ex: 8)

    @ManyToOne
    @JoinColumn(name = "level_id") // Foreign key column in the Module table
    private Level level; // Add this property

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPassingScore() {
        return passingScore;
    }

    public void setPassingScore(Double passingScore) {
        this.passingScore = passingScore;
    }

    public Double getRetakeScore() {
        return retakeScore;
    }

    public void setRetakeScore(Double retakeScore) {
        this.retakeScore = retakeScore;
    }

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }
}