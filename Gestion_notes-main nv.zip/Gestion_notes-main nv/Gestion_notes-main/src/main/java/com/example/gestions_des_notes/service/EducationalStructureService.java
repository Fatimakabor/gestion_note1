package com.example.gestions_des_notes.service;

import com.example.gestions_des_notes.DAO.EducationalStructureRepo;
import com.example.gestions_des_notes.models.EducationalStructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EducationalStructureService {

    private EducationalStructureRepo educationalStructureRepo;



    // Créer une structure pédagogique
    public EducationalStructure createStructure(EducationalStructure structure) {
        return educationalStructureRepo.save(structure);
    }

    // Modifier une structure pédagogique
    public EducationalStructure updateStructure(Long id, EducationalStructure structure) {
        EducationalStructure existingStructure = educationalStructureRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Structure pédagogique non trouvée"));
        existingStructure.setName(structure.getName());
        existingStructure.setCode(structure.getCode());
        return educationalStructureRepo.save(existingStructure);
    }

    // Supprimer une structure pédagogique
    public void deleteStructure(Long id) {
        educationalStructureRepo.deleteById(id);
    }

    // Lister toutes les structures pédagogiques
    public List<EducationalStructure> getAllStructures() {
        return educationalStructureRepo.findAll();
    }
}
