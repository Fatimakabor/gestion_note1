package com.example.gestions_des_notes.controllers;

import com.example.gestions_des_notes.models.Student;
import com.example.gestions_des_notes.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private StudentService studentService;

    // Afficher la liste des étudiants avec leurs notes
    @GetMapping("/students")
    public String showAdminPage(Model model) {
        List<Student> students = studentService.getAllStudents();
        model.addAttribute("students", students); // Ajouter la liste des étudiants au modèle
        return "admin/admin-notes"; // Retourner la vue Thymeleaf
    }

    // Afficher le formulaire pour modifier la note d'un étudiant
    @GetMapping("/students/{id}/edit-grade")
    public String showEditGradeForm(@PathVariable Long id, Model model) {
        Optional<Student> student = studentService.getStudentById(id);
        if (student.isPresent()) {
            model.addAttribute("student", student.get()); // Ajouter l'étudiant au modèle
            return "admin/edit-grade"; // Retourner la vue Thymeleaf
        } else {
            return "redirect:/admin/students"; // Rediriger si l'étudiant n'existe pas
        }
    }

    // Mettre à jour la note d'un étudiant
    @PostMapping("/students/{id}/edit-grade")
    public String updateGrade(@PathVariable Long id, @RequestParam double grade) {
        studentService.updateStudentGrade(id, grade); // Mettre à jour la note
        return "redirect:/admin/students"; // Rediriger vers la liste des étudiants
    }
}
